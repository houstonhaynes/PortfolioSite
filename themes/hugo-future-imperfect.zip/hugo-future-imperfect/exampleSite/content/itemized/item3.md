+++
type = "itemized"
author = "George Jetson"
date = "2017-06-22"
title = "Fancy App 3"
description = "Application for doing cool things."
featured = ""
featuredpath = ""
featuredalt = ""
categories = [""]
linktitle = ""
format = "Android"
link = "#"
+++

## App 3
